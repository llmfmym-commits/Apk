package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.model.AppFolder
import com.example.data.model.AppSettings
import com.example.data.model.BookmarkItem
import com.example.data.model.WebAppItem
import com.example.data.model.WebTab
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(application, database)
        viewModelScope.launch {
            repository.seedDefaultsIfEmpty()
        }
    }

    val settings: StateFlow<AppSettings> = repository.settingsFlow

    val allApps: StateFlow<List<WebAppItem>> = repository.allApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFolders: StateFlow<List<AppFolder>> = repository.allFolders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tabs: StateFlow<List<WebTab>> = repository.tabsFlow
    val bookmarks: StateFlow<List<BookmarkItem>> = repository.bookmarksFlow

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun addWebApp(
        name: String,
        type: String,
        targetUrl: String,
        iconPath: String? = null,
        iconPreset: String? = null,
        targetPage: Int = 0
    ) {
        viewModelScope.launch {
            val currentApps = allApps.value
            val nextOrder = (currentApps.filter { it.pageIndex == targetPage && it.folderId == null }.maxOfOrNull { it.orderIndex } ?: -1) + 1
            val newApp = WebAppItem(
                name = name,
                type = type,
                targetUrl = targetUrl,
                iconPath = iconPath,
                iconPreset = iconPreset ?: getRandomPresetColor(name),
                pageIndex = targetPage,
                orderIndex = nextOrder
            )
            repository.insertApp(newApp)
        }
    }

    fun updateApp(app: WebAppItem) {
        viewModelScope.launch {
            repository.updateApp(app)
        }
    }

    fun deleteApp(app: WebAppItem) {
        viewModelScope.launch {
            repository.deleteApp(app)
        }
    }

    fun markAppUsed(appId: Long) {
        viewModelScope.launch {
            repository.updateLastUsed(appId)
        }
    }

    fun moveAppToPage(appId: Long, targetPage: Int) {
        viewModelScope.launch {
            val app = allApps.value.find { it.id == appId } ?: return@launch
            val nextOrder = (allApps.value.filter { it.pageIndex == targetPage && it.folderId == null }.maxOfOrNull { it.orderIndex } ?: -1) + 1
            repository.updateAppPosition(appId, targetPage, nextOrder, null)
        }
    }

    fun moveAppToFolder(appId: Long, targetFolderId: Long?) {
        viewModelScope.launch {
            val app = allApps.value.find { it.id == appId } ?: return@launch
            val targetOrder = if (targetFolderId != null) {
                (allApps.value.filter { it.folderId == targetFolderId }.maxOfOrNull { it.orderIndex } ?: -1) + 1
            } else {
                (allApps.value.filter { it.pageIndex == app.pageIndex && it.folderId == null }.maxOfOrNull { it.orderIndex } ?: -1) + 1
            }
            repository.updateAppPosition(appId, app.pageIndex, targetOrder, targetFolderId)
        }
    }

    fun createFolder(name: String, colorHex: String, targetPage: Int = 0) {
        viewModelScope.launch {
            val nextOrder = (allFolders.value.filter { it.pageIndex == targetPage }.maxOfOrNull { it.orderIndex } ?: -1) + 1
            val folder = AppFolder(
                name = name,
                colorHex = colorHex,
                pageIndex = targetPage,
                orderIndex = nextOrder
            )
            repository.insertFolder(folder)
        }
    }

    fun deleteFolder(folder: AppFolder) {
        viewModelScope.launch {
            val appsInFolder = allApps.value.filter { it.folderId == folder.id }
            for (app in appsInFolder) {
                repository.updateAppPosition(app.id, folder.pageIndex, app.orderIndex, null)
            }
            repository.deleteFolder(folder)
        }
    }

    fun updateFolder(folder: AppFolder) {
        viewModelScope.launch {
            repository.updateFolder(folder)
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        repository.updateSettings(newSettings)
    }

    fun updatePanelOpacity(opacity: Float) {
        repository.updateSettings(settings.value.copy(panelOpacity = opacity))
    }

    fun updateWallpaper(type: String, value: String) {
        repository.updateSettings(settings.value.copy(wallpaperType = type, wallpaperValue = value))
    }

    fun addTab(title: String, url: String, iconPreset: String? = null) {
        val tab = WebTab(
            id = UUID.randomUUID().toString(),
            title = title,
            url = url,
            iconPreset = iconPreset
        )
        repository.addTab(tab)
    }

    fun removeTab(tabId: String) {
        repository.removeTab(tabId)
    }

    fun addBookmark(title: String, url: String) {
        repository.addBookmark(title, url)
    }

    fun removeBookmark(id: Long) {
        repository.removeBookmark(id)
    }

    suspend fun exportBackupJson(): String {
        return repository.exportBackupJson(allApps.value, allFolders.value)
    }

    suspend fun restoreBackupJson(json: String): Boolean {
        return repository.restoreBackupJson(json)
    }

    private fun getRandomPresetColor(seed: String): String {
        val colors = listOf(
            "#EF4444", "#F97316", "#F59E0B", "#10B981", "#06B6D4",
            "#3B82F6", "#6366F1", "#8B5CF6", "#EC4899", "#14B8A6"
        )
        val hash = seed.hashCode()
        val index = kotlin.math.abs(hash) % colors.size
        return colors[index]
    }
}
