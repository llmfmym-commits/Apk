package com.example.ui.launcher

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Square
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceCustomizationScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit
) {
    val settings by viewModel.settings.collectAsState()

    val accentColors = listOf(
        "#3B82F6", "#0284C7", "#6366F1", "#8B5CF6", "#EC4899", "#F59E0B"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "ظاهر و شخصی‌سازی",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        containerColor = Color(0xFF0B101E)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // 1. حالت تم (Light, Dark, System - matching mockup screen 10)
            SectionTitle(title = "حالت تم")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SelectCard(
                    title = "روشن",
                    icon = Icons.Default.LightMode,
                    isSelected = settings.themeMode == "LIGHT",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(themeMode = "LIGHT")) }
                )
                SelectCard(
                    title = "تاریک",
                    icon = Icons.Default.DarkMode,
                    isSelected = settings.themeMode == "DARK",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(themeMode = "DARK")) }
                )
                SelectCard(
                    title = "سیستم",
                    icon = Icons.Default.Brightness4,
                    isSelected = settings.themeMode == "SYSTEM",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(themeMode = "SYSTEM")) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2. اندازه آیکون (Small, Medium, Large - matching mockup screen 10)
            SectionTitle(title = "اندازه آیکون")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SelectCard(
                    title = "کوچک",
                    subtext = "48dp",
                    isSelected = settings.iconSize == "SMALL",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconSize = "SMALL")) }
                )
                SelectCard(
                    title = "متوسط",
                    subtext = "56dp",
                    isSelected = settings.iconSize == "MEDIUM",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconSize = "MEDIUM")) }
                )
                SelectCard(
                    title = "بزرگ",
                    subtext = "64dp",
                    isSelected = settings.iconSize == "LARGE",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconSize = "LARGE")) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. تعداد ستون‌ها (3, 4, 5 - matching mockup screen 10)
            SectionTitle(title = "تعداد ستون‌ها")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SelectCard(
                    title = "3",
                    isSelected = settings.columnCount == 3,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(columnCount = 3)) }
                )
                SelectCard(
                    title = "4",
                    isSelected = settings.columnCount == 4,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(columnCount = 4)) }
                )
                SelectCard(
                    title = "5",
                    isSelected = settings.columnCount == 5,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(columnCount = 5)) }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 4. شکل آیکون (Rounded Square, Circle, Squircle, Square)
            SectionTitle(title = "شکل آیکون")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ShapeOption(
                    name = "ROUNDED_SQUARE",
                    shape = RoundedCornerShape(14.dp),
                    isSelected = settings.iconShape == "ROUNDED_SQUARE",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconShape = "ROUNDED_SQUARE")) }
                )
                ShapeOption(
                    name = "CIRCLE",
                    shape = CircleShape,
                    isSelected = settings.iconShape == "CIRCLE",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconShape = "CIRCLE")) }
                )
                ShapeOption(
                    name = "SQUIRCLE",
                    shape = RoundedCornerShape(20.dp),
                    isSelected = settings.iconShape == "SQUIRCLE",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconShape = "SQUIRCLE")) }
                )
                ShapeOption(
                    name = "SQUARE",
                    shape = RoundedCornerShape(4.dp),
                    isSelected = settings.iconShape == "SQUARE",
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.updateSettings(settings.copy(iconShape = "SQUARE")) }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // 5. رنگ اصلی UI (Palette of circles)
            SectionTitle(title = "رنگ اصلی UI")
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(accentColors) { hex ->
                    val color = Color(android.graphics.Color.parseColor(hex))
                    val isSelected = settings.accentColorHex == hex

                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(color)
                            .clickable { viewModel.updateSettings(settings.copy(accentColorHex = hex)) }
                            .then(
                                if (isSelected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(
        text = title,
        color = Color(0xFF94A3B8),
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
fun SelectCard(
    title: String,
    icon: ImageVector? = null,
    subtext: String? = null,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) Color(0xFF1E3A8A).copy(alpha = 0.4f) else Color(0xFF1E293B),
        shape = RoundedCornerShape(12.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF38BDF8)) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
        modifier = modifier
            .height(72.dp)
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) Color(0xFF38BDF8) else Color.White,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
            }
            Text(
                text = title,
                color = if (isSelected) Color(0xFF38BDF8) else Color.White,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
            if (subtext != null) {
                Text(
                    text = subtext,
                    color = Color(0xFF94A3B8),
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
fun ShapeOption(
    name: String,
    shape: androidx.compose.ui.graphics.Shape,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = Color(0xFF1E293B),
        shape = RoundedCornerShape(12.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF38BDF8)) else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155)),
        modifier = modifier
            .height(60.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(shape)
                    .background(if (isSelected) Color(0xFF38BDF8) else Color(0xFF64748B))
            )
        }
    }
}
