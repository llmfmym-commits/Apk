package com.example.ui.browser

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.border
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.data.model.WebAppItem
import com.example.ui.keyboard.CustomInAppKeyboard
import java.io.File

class WebAppJsInterface(
    private val onInputFocused: () -> Unit
) {
    @JavascriptInterface
    fun onFocus() {
        onInputFocused()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebViewScreen(
    appItem: WebAppItem,
    onCloseBrowser: () -> Unit,
    modifier: Modifier = Modifier,
    onOpenTabs: () -> Unit = {},
    onOpenBookmarks: () -> Unit = {},
    tabsCount: Int = 1
) {
    val context = LocalContext.current
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var currentUrl by remember { mutableStateOf(appItem.targetUrl) }
    var pageTitle by remember { mutableStateOf(appItem.name) }
    var loadProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(false) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }
    var isDesktopMode by remember { mutableStateOf(appItem.desktopMode) }
    var isFullScreen by remember { mutableStateOf(appItem.fullScreen) }
    var showMenu by remember { mutableStateOf(false) }
    var showCustomKeyboard by remember { mutableStateOf(false) }

    // File chooser callback holder
    var filePathCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val fileChooserLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val uris: Array<Uri>? = when {
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                data?.data != null -> arrayOf(data.data!!)
                else -> null
            }
            filePathCallback?.onReceiveValue(uris)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    // Permission request holder for Camera / Mic
    var activePermissionRequest by remember { mutableStateOf<PermissionRequest?>(null) }

    val mediaPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        val grantedResources = mutableListOf<String>()
        if (cameraGranted) grantedResources.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
        if (audioGranted) grantedResources.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE)

        if (grantedResources.isNotEmpty()) {
            activePermissionRequest?.grant(grantedResources.toTypedArray())
        } else {
            activePermissionRequest?.deny()
        }
        activePermissionRequest = null
    }

    // Handle Android system back key
    BackHandler {
        if (showCustomKeyboard) {
            showCustomKeyboard = false
        } else if (webViewInstance?.canGoBack() == true) {
            webViewInstance?.goBack()
        } else {
            onCloseBrowser()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            if (appItem.isIncognito) {
                // Clear session cookies and cache if incognito
                webViewInstance?.clearCache(true)
                webViewInstance?.clearHistory()
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
            }
        }
    }

    // JavaScript helper executor for in-app keyboard
    val executeJsScript: (String) -> Unit = { script ->
        webViewInstance?.evaluateJavascript(script, null)
    }

    val typeCharOnWeb: (String) -> Unit = { char ->
        val escaped = char.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")
        val script = """
            (function() {
                var el = document.activeElement;
                if (!el) return;
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    var start = el.selectionStart || 0;
                    var end = el.selectionEnd || 0;
                    var val = el.value || '';
                    el.value = val.substring(0, start) + '$escaped' + val.substring(end);
                    el.selectionStart = el.selectionEnd = start + '$escaped'.length;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                } else if (el.isContentEditable) {
                    document.execCommand('insertText', false, '$escaped');
                }
            })();
        """.trimIndent()
        executeJsScript(script)
    }

    val backspaceOnWeb: () -> Unit = {
        val script = """
            (function() {
                var el = document.activeElement;
                if (!el) return;
                if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                    var start = el.selectionStart || 0;
                    var end = el.selectionEnd || 0;
                    var val = el.value || '';
                    if (start === end && start > 0) {
                        el.value = val.substring(0, start - 1) + val.substring(end);
                        el.selectionStart = el.selectionEnd = start - 1;
                    } else if (start !== end) {
                        el.value = val.substring(0, start) + val.substring(end);
                        el.selectionStart = el.selectionEnd = start;
                    }
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                } else if (el.isContentEditable) {
                    document.execCommand('delete', false, null);
                }
            })();
        """.trimIndent()
        executeJsScript(script)
    }

    val enterOnWeb: () -> Unit = {
        val script = """
            (function() {
                var el = document.activeElement;
                if (!el) return;
                var event = new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, which: 13, bubbles: true });
                el.dispatchEvent(event);
                if (el.form) {
                    el.form.submit();
                }
            })();
        """.trimIndent()
        executeJsScript(script)
    }

    Column(modifier = modifier.fillMaxSize().background(Color(0xFF0F172A))) {
        // Toolbar (hidden in full-screen mode)
        if (!isFullScreen) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF1E293B),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onCloseBrowser) {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home",
                            tint = Color(0xFF38BDF8)
                        )
                    }

                    IconButton(
                        onClick = { webViewInstance?.goBack() },
                        enabled = canGoBack
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (canGoBack) Color.White else Color(0xFF64748B)
                        )
                    }

                    IconButton(
                        onClick = { webViewInstance?.goForward() },
                        enabled = canGoForward
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Forward",
                            tint = if (canGoForward) Color.White else Color(0xFF64748B)
                        )
                    }

                    IconButton(onClick = { webViewInstance?.reload() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reload",
                            tint = Color.White
                        )
                    }

                    // Title & URL container
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (currentUrl.startsWith("https://") || currentUrl.startsWith("file://")) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Secure",
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                            }
                            Text(
                                text = pageTitle.ifBlank { appItem.name },
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            text = currentUrl,
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Bookmarks Button
                    IconButton(onClick = onOpenBookmarks, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Bookmark,
                            contentDescription = "Bookmarks",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Tabs Count Badge Button (matching mockup screen 3 tabs icon)
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .size(24.dp)
                            .border(1.5.dp, Color.White, RoundedCornerShape(6.dp))
                            .clickable(onClick = onOpenTabs),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$tabsCount",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Keyboard Toggle Button
                    IconButton(onClick = { showCustomKeyboard = !showCustomKeyboard }) {
                        Icon(
                            imageVector = Icons.Default.Keyboard,
                            contentDescription = "Toggle Keyboard",
                            tint = if (showCustomKeyboard) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                        )
                    }

                    // Fullscreen Button
                    IconButton(onClick = { isFullScreen = true }) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = "Full Screen",
                            tint = Color.White
                        )
                    }

                    // Overflow Menu
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More Options",
                                tint = Color.White
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(if (isDesktopMode) "حالت موبایل" else "حالت کامپیوتر (Desktop)") },
                                onClick = {
                                    isDesktopMode = !isDesktopMode
                                    webViewInstance?.settings?.userAgentString = if (isDesktopMode) {
                                        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                                    } else {
                                        WebSettings.getDefaultUserAgent(context)
                                    }
                                    webViewInstance?.reload()
                                    showMenu = false
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isDesktopMode) Icons.Default.Smartphone else Icons.Default.Computer,
                                        contentDescription = null
                                    )
                                }
                            )

                            DropdownMenuItem(
                                text = { Text("کپی آدرس (Copy URL)") },
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("URL", currentUrl))
                                    Toast.makeText(context, "آدرس کپی شد", Toast.LENGTH_SHORT).show()
                                    showMenu = false
                                },
                                leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) }
                            )

                            DropdownMenuItem(
                                text = { Text("اشتراک‌گذاری (Share)") },
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, currentUrl)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share URL"))
                                    showMenu = false
                                },
                                leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                            )

                            DropdownMenuItem(
                                text = { Text("باز کردن در مرورگر اصلی") },
                                onClick = {
                                    try {
                                        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(currentUrl))
                                        context.startActivity(browserIntent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "مرورگر یافت نشد", Toast.LENGTH_SHORT).show()
                                    }
                                    showMenu = false
                                },
                                leadingIcon = { Icon(Icons.Default.OpenInBrowser, contentDescription = null) }
                            )
                        }
                    }
                }

                if (isLoading) {
                    LinearProgressIndicator(
                        progress = { loadProgress },
                        modifier = Modifier.fillMaxWidth().height(2.dp),
                        color = Color(0xFF38BDF8),
                        trackColor = Color.Transparent
                    )
                }
            }
        } else {
            // Minimal floating exit full-screen icon
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                contentAlignment = Alignment.TopEnd
            ) {
                IconButton(
                    onClick = { isFullScreen = false },
                    modifier = Modifier.background(Color(0x88000000), shape = androidx.compose.foundation.shape.CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.FullscreenExit,
                        contentDescription = "Exit Fullscreen",
                        tint = Color.White
                    )
                }
            }
        }

        // Web Content View
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        webViewInstance = this

                        // Configure WebSettings
                        settings.apply {
                            javaScriptEnabled = appItem.javascriptEnabled
                            domStorageEnabled = true
                            databaseEnabled = true
                            allowFileAccess = true
                            allowContentAccess = true
                            mediaPlaybackRequiresUserGesture = false
                            setSupportMultipleWindows(false)
                            setSupportZoom(appItem.zoomEnabled)
                            builtInZoomControls = appItem.zoomEnabled
                            displayZoomControls = false
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            cacheMode = if (appItem.cacheEnabled && !appItem.isIncognito) {
                                WebSettings.LOAD_DEFAULT
                            } else {
                                WebSettings.LOAD_NO_CACHE
                            }
                            if (isDesktopMode) {
                                userAgentString = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                            }
                        }

                        // Cookie settings
                        val cookieManager = CookieManager.getInstance()
                        cookieManager.setAcceptCookie(appItem.cookiesEnabled && !appItem.isIncognito)
                        cookieManager.setAcceptThirdPartyCookies(this, appItem.cookiesEnabled && !appItem.isIncognito)

                        // Add JS Interface for Focus detection
                        addJavascriptInterface(
                            WebAppJsInterface {
                                // Called when input element gains focus
                                (ctx as? Activity)?.runOnUiThread {
                                    showCustomKeyboard = true
                                }
                            },
                            "AndroidAppKeyboard"
                        )

                        // Internal Navigation WebViewClient
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                val url = request?.url?.toString() ?: return false
                                val scheme = request.url.scheme?.lowercase() ?: ""

                                // Keep all web & local file requests strictly inside the internal WebView!
                                if (scheme == "http" || scheme == "https" || scheme == "file") {
                                    return false
                                }

                                // External intents for tel, mailto, etc.
                                return try {
                                    val intent = Intent(Intent.ACTION_VIEW, request.url)
                                    ctx.startActivity(intent)
                                    true
                                } catch (e: Exception) {
                                    false
                                }
                            }

                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                isLoading = true
                                url?.let { currentUrl = it }
                                canGoBack = view?.canGoBack() == true
                                canGoForward = view?.canGoForward() == true
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                isLoading = false
                                url?.let { currentUrl = it }
                                pageTitle = view?.title ?: ""
                                canGoBack = view?.canGoBack() == true
                                canGoForward = view?.canGoForward() == true
                                CookieManager.getInstance().flush()

                                // Inject script to listen to input focus
                                val focusObserverScript = """
                                    (function() {
                                        if (window.__appKeyboardObserved) return;
                                        window.__appKeyboardObserved = true;
                                        document.addEventListener('focusin', function(e) {
                                            var target = e.target;
                                            if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) {
                                                if (window.AndroidAppKeyboard) {
                                                    window.AndroidAppKeyboard.onFocus();
                                                }
                                            }
                                        }, true);
                                    })();
                                """.trimIndent()
                                view?.evaluateJavascript(focusObserverScript, null)
                            }
                        }

                        // WebChromeClient for File Chooser, Progress, & Permissions
                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                loadProgress = newProgress / 100f
                                if (newProgress >= 100) isLoading = false
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                super.onReceivedTitle(view, title)
                                if (!title.isNullOrBlank()) pageTitle = title
                            }

                            override fun onShowFileChooser(
                                webView: WebView?,
                                filePathCallbackInternal: ValueCallback<Array<Uri>>?,
                                fileChooserParams: FileChooserParams?
                            ): Boolean {
                                filePathCallback?.onReceiveValue(null)
                                filePathCallback = filePathCallbackInternal

                                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                                    type = "*/*"
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                }
                                try {
                                    fileChooserLauncher.launch(intent)
                                } catch (e: Exception) {
                                    filePathCallback?.onReceiveValue(null)
                                    filePathCallback = null
                                    return false
                                }
                                return true
                            }

                            override fun onPermissionRequest(request: PermissionRequest?) {
                                if (request == null) return
                                activePermissionRequest = request

                                val requiredPermissions = mutableListOf<String>()
                                for (resource in request.resources) {
                                    if (resource == PermissionRequest.RESOURCE_VIDEO_CAPTURE) {
                                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                            requiredPermissions.add(Manifest.permission.CAMERA)
                                        }
                                    }
                                    if (resource == PermissionRequest.RESOURCE_AUDIO_CAPTURE) {
                                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                            requiredPermissions.add(Manifest.permission.RECORD_AUDIO)
                                        }
                                    }
                                }

                                if (requiredPermissions.isNotEmpty()) {
                                    mediaPermissionLauncher.launch(requiredPermissions.toTypedArray())
                                } else {
                                    request.grant(request.resources)
                                }
                            }
                        }

                        // Download Listener
                        setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                            try {
                                val request = DownloadManager.Request(Uri.parse(url)).apply {
                                    setMimeType(mimeType)
                                    addRequestHeader("cookie", CookieManager.getInstance().getCookie(url))
                                    addRequestHeader("User-Agent", userAgent)
                                    setDescription("Downloading file...")
                                    setTitle(Uri.parse(url).lastPathSegment ?: "download")
                                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                    setDestinationInExternalPublicDir(
                                        Environment.DIRECTORY_DOWNLOADS,
                                        Uri.parse(url).lastPathSegment ?: "file_${System.currentTimeMillis()}"
                                    )
                                }
                                val dm = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                dm.enqueue(request)
                                Toast.makeText(ctx, "در حال دانلود فایل...", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "خطا در شروع دانلود: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }

                        // Load initial URL
                        if (appItem.targetUrl.startsWith("/")) {
                            loadUrl("file://" + appItem.targetUrl)
                        } else {
                            loadUrl(appItem.targetUrl)
                        }
                    }
                }
            )
        }

        // Custom In-App Keyboard Slide-up Panel
        AnimatedVisibility(
            visible = showCustomKeyboard,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            CustomInAppKeyboard(
                onCharTyped = { ch -> typeCharOnWeb(ch) },
                onBackspace = { backspaceOnWeb() },
                onEnter = { enterOnWeb() },
                onDismiss = { showCustomKeyboard = false }
            )
        }
    }
}
