package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppFolder
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {
    @Query("SELECT * FROM app_folders ORDER BY pageIndex ASC, orderIndex ASC")
    fun getAllFolders(): Flow<List<AppFolder>>

    @Query("SELECT * FROM app_folders WHERE id = :id LIMIT 1")
    suspend fun getFolderById(id: Long): AppFolder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolder(folder: AppFolder): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFolders(folders: List<AppFolder>)

    @Update
    suspend fun updateFolder(folder: AppFolder)

    @Delete
    suspend fun deleteFolder(folder: AppFolder)

    @Query("DELETE FROM app_folders WHERE id = :id")
    suspend fun deleteFolderById(id: Long)

    @Query("UPDATE app_folders SET pageIndex = :pageIndex, orderIndex = :orderIndex WHERE id = :id")
    suspend fun updatePosition(id: Long, pageIndex: Int, orderIndex: Int)

    @Query("DELETE FROM app_folders")
    suspend fun clearAll()
}
