package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppFolder
import com.example.data.model.AppSettings
import com.example.data.model.BookmarkItem
import com.example.data.model.WebAppItem
import com.example.data.model.WebTab
import com.example.util.FileUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class AppRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    private val webAppDao = database.webAppDao()
    private val folderDao = database.folderDao()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("app_settings_prefs_v2", Context.MODE_PRIVATE)

    val allApps: Flow<List<WebAppItem>> = webAppDao.getAllApps()
    val allFolders: Flow<List<AppFolder>> = folderDao.getAllFolders()

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow = _settingsFlow.asStateFlow()

    // Tabs state
    private val _tabsFlow = MutableStateFlow<List<WebTab>>(loadInitialTabs())
    val tabsFlow = _tabsFlow.asStateFlow()

    // Bookmarks state
    private val _bookmarksFlow = MutableStateFlow<List<BookmarkItem>>(loadInitialBookmarks())
    val bookmarksFlow = _bookmarksFlow.asStateFlow()

    private fun loadSettings(): AppSettings {
        return AppSettings(
            wallpaperType = prefs.getString("wallpaper_type", "DEFAULT") ?: "DEFAULT",
            wallpaperValue = prefs.getString("wallpaper_value", "DEFAULT") ?: "DEFAULT",
            panelOpacity = prefs.getFloat("panel_opacity", 0.70f),
            themeMode = prefs.getString("theme_mode", "DARK") ?: "DARK",
            columnCount = prefs.getInt("column_count", 4),
            iconSize = prefs.getString("icon_size", "MEDIUM") ?: "MEDIUM",
            iconShape = prefs.getString("icon_shape", "SQUIRCLE") ?: "SQUIRCLE",
            accentColorHex = prefs.getString("accent_color_hex", "#3B82F6") ?: "#3B82F6",
            appLockEnabled = prefs.getBoolean("app_lock_enabled", false),
            masterPin = prefs.getString("master_pin", "") ?: "",
            sortMode = prefs.getString("sort_mode", "MANUAL") ?: "MANUAL",
            jsEnabledGlobal = prefs.getBoolean("js_enabled_global", true),
            cookiesEnabledGlobal = prefs.getBoolean("cookies_enabled_global", true),
            localStorageEnabledGlobal = prefs.getBoolean("local_storage_enabled_global", true),
            zoomEnabledGlobal = prefs.getBoolean("zoom_enabled_global", false),
            desktopModeGlobal = prefs.getBoolean("desktop_mode_global", false),
            incognitoGlobal = prefs.getBoolean("incognito_global", false),
            userAgentGlobal = prefs.getString("user_agent_global", "Mobile") ?: "Mobile"
        )
    }

    fun updateSettings(newSettings: AppSettings) {
        prefs.edit().apply {
            putString("wallpaper_type", newSettings.wallpaperType)
            putString("wallpaper_value", newSettings.wallpaperValue)
            putFloat("panel_opacity", newSettings.panelOpacity)
            putString("theme_mode", newSettings.themeMode)
            putInt("column_count", newSettings.columnCount)
            putString("icon_size", newSettings.iconSize)
            putString("icon_shape", newSettings.iconShape)
            putString("accent_color_hex", newSettings.accentColorHex)
            putBoolean("app_lock_enabled", newSettings.appLockEnabled)
            putString("master_pin", newSettings.masterPin)
            putString("sort_mode", newSettings.sortMode)
            putBoolean("js_enabled_global", newSettings.jsEnabledGlobal)
            putBoolean("cookies_enabled_global", newSettings.cookiesEnabledGlobal)
            putBoolean("local_storage_enabled_global", newSettings.localStorageEnabledGlobal)
            putBoolean("zoom_enabled_global", newSettings.zoomEnabledGlobal)
            putBoolean("desktop_mode_global", newSettings.desktopModeGlobal)
            putBoolean("incognito_global", newSettings.incognitoGlobal)
            putString("user_agent_global", newSettings.userAgentGlobal)
            apply()
        }
        _settingsFlow.value = newSettings
    }

    private fun loadInitialTabs(): List<WebTab> {
        return listOf(
            WebTab("1", "YouTube", "https://www.youtube.com", "#EF4444"),
            WebTab("2", "Google", "https://www.google.com", "#4285F4"),
            WebTab("3", "ChatGPT", "https://chat.openai.com", "#10A37F")
        )
    }

    fun addTab(tab: WebTab) {
        _tabsFlow.value = _tabsFlow.value + tab
    }

    fun removeTab(tabId: String) {
        _tabsFlow.value = _tabsFlow.value.filter { it.id != tabId }
    }

    private fun loadInitialBookmarks(): List<BookmarkItem> {
        return listOf(
            BookmarkItem(1, "YouTube", "https://youtube.com", "#EF4444"),
            BookmarkItem(2, "Google", "https://google.com", "#4285F4"),
            BookmarkItem(3, "ChatGPT", "https://chat.openai.com", "#10A37F"),
            BookmarkItem(4, "Instagram", "https://instagram.com", "#EC4899"),
            BookmarkItem(5, "Telegram", "https://telegram.org", "#0284C7"),
            BookmarkItem(6, "Wikipedia", "https://wikipedia.org", "#64748B")
        )
    }

    fun addBookmark(title: String, url: String) {
        val newBookmark = BookmarkItem(
            id = System.currentTimeMillis(),
            title = title,
            url = url,
            iconColor = "#3B82F6"
        )
        _bookmarksFlow.value = _bookmarksFlow.value + newBookmark
    }

    fun removeBookmark(id: Long) {
        _bookmarksFlow.value = _bookmarksFlow.value.filter { it.id != id }
    }

    suspend fun getAppById(id: Long): WebAppItem? = webAppDao.getAppById(id)

    suspend fun insertApp(app: WebAppItem): Long = webAppDao.insertApp(app)

    suspend fun updateApp(app: WebAppItem) = webAppDao.updateApp(app)

    suspend fun deleteApp(app: WebAppItem) {
        webAppDao.deleteApp(app)
        if (app.type != "WEB_URL") {
            FileUtils.deleteAppDirectory(context, app.id.toString())
        }
    }

    suspend fun updateLastUsed(appId: Long) {
        webAppDao.updateLastUsed(appId, System.currentTimeMillis())
    }

    suspend fun updateAppPosition(id: Long, pageIndex: Int, orderIndex: Int, folderId: Long?) {
        webAppDao.updatePosition(id, pageIndex, orderIndex, folderId)
    }

    suspend fun insertFolder(folder: AppFolder): Long = folderDao.insertFolder(folder)

    suspend fun updateFolder(folder: AppFolder) = folderDao.updateFolder(folder)

    suspend fun deleteFolder(folder: AppFolder) {
        folderDao.deleteFolder(folder)
    }

    suspend fun updateFolderPosition(id: Long, pageIndex: Int, orderIndex: Int) {
        folderDao.updatePosition(id, pageIndex, orderIndex)
    }

    /**
     * Seeds initial apps and folder exactly as shown in the mockup design.
     */
    suspend fun seedDefaultsIfEmpty() {
        val seeded = prefs.getBoolean("has_seeded_mockup_apps_v3", false)
        if (!seeded) {
            // Seed Social Folder
            val socialFolderId = folderDao.insertFolder(
                AppFolder(
                    name = "Social",
                    icon = "folder",
                    colorHex = "#3B82F6",
                    pageIndex = 0,
                    orderIndex = 11
                )
            )

            // Seed Offline HTML Demo App
            val htmlAppPath = FileUtils.saveHtmlProject(
                context = context,
                appId = "html_app_demo",
                htmlContent = """
                    <div style="font-family:system-ui; text-align:center; padding:20px; color:#f8fafc;">
                        <h2>⚡ HTML App</h2>
                        <p>برنامه آفلاین HTML اجرا شده درون WebView</p>
                        <button onclick="alert('سلام از HTML5!')" style="padding:10px 20px; background:#3b82f6; color:white; border:none; border-radius:8px; font-weight:bold; cursor:pointer;">کلیک کنید</button>
                    </div>
                """.trimIndent(),
                cssContent = "body { background: #0f172a; margin: 0; display:flex; justify-content:center; align-items:center; min-height:100vh; }",
                jsContent = ""
            )

            // Main 11 apps matching mockup screen 1
            val defaultApps = listOf(
                WebAppItem(name = "YouTube", type = "WEB_URL", targetUrl = "https://www.youtube.com", iconPreset = "#EF4444", pageIndex = 0, orderIndex = 0),
                WebAppItem(name = "ChatGPT", type = "WEB_URL", targetUrl = "https://chat.openai.com", iconPreset = "#10A37F", pageIndex = 0, orderIndex = 1),
                WebAppItem(name = "Google", type = "WEB_URL", targetUrl = "https://www.google.com", iconPreset = "#4285F4", pageIndex = 0, orderIndex = 2),
                WebAppItem(name = "Telegram", type = "WEB_URL", targetUrl = "https://web.telegram.org", iconPreset = "#0284C7", pageIndex = 0, orderIndex = 3),
                WebAppItem(name = "Instagram", type = "WEB_URL", targetUrl = "https://www.instagram.com", iconPreset = "#EC4899", pageIndex = 0, orderIndex = 4),
                WebAppItem(name = "X", type = "WEB_URL", targetUrl = "https://x.com", iconPreset = "#000000", pageIndex = 0, orderIndex = 5),
                WebAppItem(name = "WhatsApp", type = "WEB_URL", targetUrl = "https://web.whatsapp.com", iconPreset = "#22C55E", pageIndex = 0, orderIndex = 6),
                WebAppItem(name = "Facebook", type = "WEB_URL", targetUrl = "https://www.facebook.com", iconPreset = "#1877F2", pageIndex = 0, orderIndex = 7),
                WebAppItem(name = "My Site", type = "WEB_URL", targetUrl = "https://example.com", iconPreset = "#10B981", pageIndex = 0, orderIndex = 8),
                WebAppItem(name = "Game", type = "WEB_URL", targetUrl = "https://plays.org", iconPreset = "#F59E0B", pageIndex = 0, orderIndex = 9),
                WebAppItem(name = "HTML App", type = "HTML", targetUrl = htmlAppPath, iconPreset = "#8B5CF6", pageIndex = 0, orderIndex = 10)
            )

            for (app in defaultApps) {
                webAppDao.insertApp(app)
            }

            // Seed apps inside the Social folder as well
            val folderApps = listOf(
                WebAppItem(name = "YouTube", type = "WEB_URL", targetUrl = "https://www.youtube.com", iconPreset = "#EF4444", folderId = socialFolderId, orderIndex = 0),
                WebAppItem(name = "Instagram", type = "WEB_URL", targetUrl = "https://www.instagram.com", iconPreset = "#EC4899", folderId = socialFolderId, orderIndex = 1),
                WebAppItem(name = "Telegram", type = "WEB_URL", targetUrl = "https://web.telegram.org", iconPreset = "#0284C7", folderId = socialFolderId, orderIndex = 2),
                WebAppItem(name = "X", type = "WEB_URL", targetUrl = "https://x.com", iconPreset = "#000000", folderId = socialFolderId, orderIndex = 3),
                WebAppItem(name = "WhatsApp", type = "WEB_URL", targetUrl = "https://web.whatsapp.com", iconPreset = "#22C55E", folderId = socialFolderId, orderIndex = 4),
                WebAppItem(name = "Facebook", type = "WEB_URL", targetUrl = "https://www.facebook.com", iconPreset = "#1877F2", folderId = socialFolderId, orderIndex = 5)
            )
            for (app in folderApps) {
                webAppDao.insertApp(app)
            }

            prefs.edit().putBoolean("has_seeded_mockup_apps_v3", true).apply()
        }
    }

    suspend fun exportBackupJson(apps: List<WebAppItem>, folders: List<AppFolder>): String {
        val root = JSONObject()
        val settings = _settingsFlow.value

        val settingsJson = JSONObject().apply {
            put("wallpaperType", settings.wallpaperType)
            put("wallpaperValue", settings.wallpaperValue)
            put("panelOpacity", settings.panelOpacity.toDouble())
            put("themeMode", settings.themeMode)
            put("columnCount", settings.columnCount)
            put("iconSize", settings.iconSize)
            put("iconShape", settings.iconShape)
            put("accentColorHex", settings.accentColorHex)
            put("appLockEnabled", settings.appLockEnabled)
            put("masterPin", settings.masterPin)
            put("sortMode", settings.sortMode)
        }
        root.put("settings", settingsJson)

        val foldersJson = JSONArray()
        for (f in folders) {
            val fObj = JSONObject().apply {
                put("id", f.id)
                put("name", f.name)
                put("icon", f.icon)
                put("colorHex", f.colorHex)
                put("pageIndex", f.pageIndex)
                put("orderIndex", f.orderIndex)
            }
            foldersJson.put(fObj)
        }
        root.put("folders", foldersJson)

        val appsJson = JSONArray()
        for (a in apps) {
            val aObj = JSONObject().apply {
                put("name", a.name)
                put("type", a.type)
                put("targetUrl", a.targetUrl)
                put("iconPreset", a.iconPreset ?: "")
                put("pageIndex", a.pageIndex)
                put("orderIndex", a.orderIndex)
                put("folderId", a.folderId ?: -1L)
                put("isLocked", a.isLocked)
                put("javascriptEnabled", a.javascriptEnabled)
                put("desktopMode", a.desktopMode)
            }
            appsJson.put(aObj)
        }
        root.put("apps", appsJson)

        return root.toString(2)
    }

    suspend fun restoreBackupJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)

            if (root.has("settings")) {
                val s = root.getJSONObject("settings")
                val restoredSettings = AppSettings(
                    wallpaperType = s.optString("wallpaperType", "DEFAULT"),
                    wallpaperValue = s.optString("wallpaperValue", "DEFAULT"),
                    panelOpacity = s.optDouble("panelOpacity", 0.70).toFloat(),
                    themeMode = s.optString("themeMode", "DARK"),
                    columnCount = s.optInt("columnCount", 4),
                    iconSize = s.optString("iconSize", "MEDIUM"),
                    iconShape = s.optString("iconShape", "SQUIRCLE"),
                    accentColorHex = s.optString("accentColorHex", "#3B82F6"),
                    appLockEnabled = s.optBoolean("appLockEnabled", false),
                    masterPin = s.optString("masterPin", ""),
                    sortMode = s.optString("sortMode", "MANUAL")
                )
                updateSettings(restoredSettings)
            }

            if (root.has("folders")) {
                val fArray = root.getJSONArray("folders")
                for (i in 0 until fArray.length()) {
                    val obj = fArray.getJSONObject(i)
                    val folder = AppFolder(
                        name = obj.getString("name"),
                        icon = obj.optString("icon", "folder"),
                        colorHex = obj.optString("colorHex", "#3B82F6"),
                        pageIndex = obj.optInt("pageIndex", 0),
                        orderIndex = obj.optInt("orderIndex", 0)
                    )
                    folderDao.insertFolder(folder)
                }
            }

            if (root.has("apps")) {
                val aArray = root.getJSONArray("apps")
                for (i in 0 until aArray.length()) {
                    val obj = aArray.getJSONObject(i)
                    val folderId = obj.optLong("folderId", -1L)
                    val app = WebAppItem(
                        name = obj.getString("name"),
                        type = obj.getString("type"),
                        targetUrl = obj.getString("targetUrl"),
                        iconPreset = obj.optString("iconPreset", "#3B82F6"),
                        pageIndex = obj.optInt("pageIndex", 0),
                        orderIndex = obj.optInt("orderIndex", 0),
                        folderId = if (folderId > 0) folderId else null,
                        isLocked = obj.optBoolean("isLocked", false),
                        javascriptEnabled = obj.optBoolean("javascriptEnabled", true),
                        desktopMode = obj.optBoolean("desktopMode", false)
                    )
                    webAppDao.insertApp(app)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
