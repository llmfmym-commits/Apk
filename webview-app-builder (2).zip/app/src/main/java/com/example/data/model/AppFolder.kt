package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_folders")
data class AppFolder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val icon: String = "folder",
    val colorHex: String = "#3B82F6",
    val pageIndex: Int = 0,
    val orderIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
