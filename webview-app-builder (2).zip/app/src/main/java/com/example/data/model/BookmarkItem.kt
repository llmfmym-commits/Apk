package com.example.data.model

data class BookmarkItem(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val url: String,
    val iconColor: String = "#3B82F6",
    val iconType: String = "WEB"
)
