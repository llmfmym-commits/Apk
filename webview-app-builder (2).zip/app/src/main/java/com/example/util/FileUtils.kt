package com.example.util

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object FileUtils {

    /**
     * Copies a selected image Uri into the app's internal icons directory.
     * Returns the local file path.
     */
    fun saveIconFromUri(context: Context, uri: Uri): String? {
        return try {
            val iconsDir = File(context.filesDir, "app_icons").apply { if (!exists()) mkdirs() }
            val fileName = "icon_${UUID.randomUUID()}.png"
            val targetFile = File(iconsDir, fileName)

            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            targetFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Saves raw HTML/CSS/JS into an HTML app folder.
     * Returns the absolute path of index.html.
     */
    fun saveHtmlProject(
        context: Context,
        appId: String,
        htmlContent: String,
        cssContent: String = "",
        jsContent: String = ""
    ): String {
        val appDir = File(File(context.filesDir, "html_apps"), appId).apply { if (!exists()) mkdirs() }
        
        // Write index.html with links to style.css and script.js if provided
        val fullHtml = buildString {
            append("<!DOCTYPE html>\n<html>\n<head>\n")
            append("<meta charset=\"UTF-8\">\n")
            append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n")
            if (cssContent.isNotBlank()) {
                append("<style>\n").append(cssContent).append("\n</style>\n")
            }
            append("</head>\n<body>\n")
            append(htmlContent)
            if (jsContent.isNotBlank()) {
                append("\n<script>\n").append(jsContent).append("\n</script>\n")
            }
            append("</body>\n</html>")
        }

        val indexFile = File(appDir, "index.html")
        indexFile.writeText(fullHtml)
        return indexFile.absolutePath
    }

    /**
     * Saves a single uploaded HTML file into a dedicated project directory.
     */
    fun saveSingleHtmlFile(context: Context, appId: String, uri: Uri): String? {
        return try {
            val appDir = File(File(context.filesDir, "html_apps"), appId).apply { if (!exists()) mkdirs() }
            val indexFile = File(appDir, "index.html")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(indexFile).use { output ->
                    input.copyTo(output)
                }
            }
            indexFile.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Extracts an uploaded ZIP project into a dedicated directory using ZipSecurityUtil.
     */
    fun extractZipProject(context: Context, appId: String, zipUri: Uri): String? {
        return try {
            val appDir = File(File(context.filesDir, "html_apps"), appId).apply { if (!exists()) mkdirs() }
            context.contentResolver.openInputStream(zipUri)?.use { input ->
                val indexFile = ZipSecurityUtil.extractSafely(input, appDir)
                indexFile?.absolutePath ?: run {
                    // Try to search recursively if index.html is in a subfolder
                    findFirstIndexHtml(appDir)?.absolutePath
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun findFirstIndexHtml(dir: File): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.isFile && f.name.equals("index.html", ignoreCase = true)) {
                return f
            }
        }
        for (f in files) {
            if (f.isDirectory) {
                val found = findFirstIndexHtml(f)
                if (found != null) return found
            }
        }
        return null
    }

    /**
     * Cleans up an HTML project directory when deleted.
     */
    fun deleteAppDirectory(context: Context, appId: String) {
        val appDir = File(File(context.filesDir, "html_apps"), appId)
        if (appDir.exists()) {
            appDir.deleteRecursively()
        }
    }
}
